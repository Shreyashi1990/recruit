<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LinkedInSetting extends Model
{

}
