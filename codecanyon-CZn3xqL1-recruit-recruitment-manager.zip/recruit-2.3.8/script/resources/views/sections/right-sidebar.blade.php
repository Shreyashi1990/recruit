<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-light right-sidebar">
    <!-- Control sidebar content goes here -->
    <div class="slimscrollright" id="right-sidebar-content">

    </div>
</aside>
<!-- /.control-sidebar -->