<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': aktywuj, by posortować kolumnę rosnąco',
      'sortDescending' => ': aktywuj, by posortować kolumnę malejąco',
    ),
    'emptyTable' => 'Brak danych',
    'info' => 'Pozycje od _START_ do _END_ z _TOTAL_ łącznie',
    'infoEmpty' => 'Pozycji 0 z 0 dostępnych',
    'infoFiltered' => '(filtrowanie spośród _MAX_ dostępnych pozycji)',
    'infoThousands' => ',',
    'lengthMenu' => 'Pokaż _MENU_ pozycji',
    'loadingRecords' => 'Wczytywanie...',
    'paginate' => 
    array (
      'first' => 'Pierwsza',
      'last' => 'Ostatnia',
      'next' => 'Następna',
      'previous' => 'Poprzednia',
    ),
    'processing' => 'Przetwarzanie...',
    'search' => 'Szukaj:',
    'zeroRecords' => 'Nie znaleziono pasujących pozycji',
  ),
);
