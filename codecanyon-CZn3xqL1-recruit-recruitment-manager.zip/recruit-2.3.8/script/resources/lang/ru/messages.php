<?php

return array (
  'title' => 'Установка Laravel',
  'next' => 'Следующий шаг',
  'welcome' => 
  array (
    'title' => 'Установка Laravel',
    'message' => 'Добро пожаловать в первоначальную настройку фреймворка Laravel.',
  ),
  'requirements' => 
  array (
    'title' => 'Необходимые модули',
  ),
  'permissions' => 
  array (
    'title' => 'Проверка прав на папках',
  ),
  'environment' => 
  array (
    'title' => 'Настройки окружения',
    'save' => 'Сохранить .env',
    'success' => 'Настройки успешно сохранены в файле .env',
    'errors' => 'Произошла ошибка при сохранении файла .env, пожалуйста, сохраните его вручную',
  ),
  'final' => 
  array (
    'title' => 'Готово',
    'finished' => 'Приложение успешно настроено.',
    'exit' => 'Нажмите для выхода',
  ),
);
