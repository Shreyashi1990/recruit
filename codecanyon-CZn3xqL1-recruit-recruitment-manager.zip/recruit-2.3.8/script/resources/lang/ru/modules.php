<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': активировать для сортировки столбца по возрастанию',
      'sortDescending' => ': активировать для сортировки столбца по убыванию',
    ),
    'emptyTable' => 'В таблице отсутствуют данные',
    'info' => 'Записи с _START_ до _END_ из _TOTAL_ записей',
    'infoEmpty' => 'Записи с 0 до 0 из 0 записей',
    'infoFiltered' => '(отфильтровано из _MAX_ записей)',
    'infoThousands' => ',',
    'lengthMenu' => 'Показать _MENU_ записей',
    'loadingRecords' => 'Загрузка записей...',
    'paginate' => 
    array (
      'first' => 'Первая',
      'last' => 'Последняя',
      'next' => 'Следующая',
      'previous' => 'Предыдущая',
    ),
    'processing' => 'Подождите...',
    'search' => 'Поиск:',
    'zeroRecords' => 'Записи отсутствуют.',
  ),
);
