<?php

return array (
  'title' => 'Laravel安裝程序',
  'next' => '下一步',
  'finish' => '安裝',
  'welcome' => 
  array (
    'title' => '歡迎來到Laravel安裝程序',
    'message' => '歡迎來到安裝嚮導.',
  ),
  'requirements' => 
  array (
    'title' => '環境要求',
  ),
  'permissions' => 
  array (
    'title' => '權限',
  ),
  'environment' => 
  array (
    'title' => '環境設置',
    'save' => '保存 .env',
    'success' => '.env 文件保存成功.',
    'errors' => '無法保存 .env 文件, 請手動創建它.',
  ),
  'final' => 
  array (
    'title' => '完成',
    'finished' => '應用已成功安裝.',
    'exit' => '點擊退出',
  ),
);
