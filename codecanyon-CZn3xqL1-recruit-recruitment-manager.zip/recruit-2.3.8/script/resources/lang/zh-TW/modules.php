<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': 以升序排列此列',
      'sortDescending' => ': 以降序排列此列',
    ),
    'emptyTable' => '表中數據為空',
    'info' => '顯示第 _START_ 至 _END_ 項結果，共 _TOTAL_ 項',
    'infoEmpty' => '顯示第 0 至 0 項結果，共 0 項',
    'infoFiltered' => '(由 _MAX_ 項結果過濾)',
    'infoThousands' => ',',
    'lengthMenu' => '顯示 _MENU_ 項結果',
    'loadingRecords' => '載入中...',
    'paginate' => 
    array (
      'first' => '首頁',
      'last' => '末頁',
      'next' => '下頁',
      'previous' => '上頁',
    ),
    'processing' => '處理中...',
    'search' => '搜索:',
    'zeroRecords' => '沒有匹配結果',
  ),
);
