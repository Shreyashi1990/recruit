<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': aktiveeri, et sortida veerg kasvavalt',
      'sortDescending' => ': aktiveerige kahaneva veeru sortimiseks',
    ),
    'emptyTable' => 'Tabelis andmed puuduvad',
    'info' => 'Kuvatud: _TOTAL_ kirjet (_START_-_END_)',
    'infoEmpty' => 'Otsinguvasteid ei leitud',
    'infoFiltered' => '- filteeritud _MAX_ kirje seast.',
    'infoPostFix' => 'K&otilde;ik kuvatud kirjed p&otilde;hinevad reaalsetel tulemustel.',
    'infoThousands' => ',',
    'lengthMenu' => 'N&auml;ita kirjeid _MENU_ kaupa',
    'loadingRecords' => 'Laadimine ...',
    'paginate' => 
    array (
      'first' => 'Algus',
      'last' => 'Viimane',
      'next' => 'Järgmine',
      'previous' => 'Eelmine',
    ),
    'processing' => 'Palun oodake, koostan kuvamiseks nimekirja!',
    'search' => 'Otsi k&otilde;ikide tulemuste seast:',
    'zeroRecords' => 'Otsitavat vastet ei leitud.',
  ),
);
