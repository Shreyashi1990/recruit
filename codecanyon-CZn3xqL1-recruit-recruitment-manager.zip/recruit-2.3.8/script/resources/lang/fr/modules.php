<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': activer pour trier la colonne par ordre croissant',
      'sortDescending' => ': activer pour trier la colonne par ordre d&eacute;croissant',
    ),
    'emptyTable' => 'Aucune donn&eacute;e disponible dans le tableau',
    'info' => 'Affichage de l\'&eacute;l&eacute;ment _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments',
    'infoEmpty' => 'Affichage de l\'&eacute;l&eacute;ment 0 &agrave; 0 sur 0 &eacute;l&eacute;ment',
    'infoFiltered' => '(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)',
    'infoThousands' => ',',
    'lengthMenu' => 'Afficher _MENU_ &eacute;l&eacute;ments',
    'loadingRecords' => 'Chargement en cours...',
    'paginate' => 
    array (
      'first' => 'Premier',
      'last' => 'Dernier',
      'next' => 'Suivant',
      'previous' => 'Pr&eacute;c&eacute;dent',
    ),
    'processing' => 'Traitement en cours...',
    'search' => 'Rechercher&nbsp;:',
    'zeroRecords' => 'Aucun &eacute;l&eacute;ment &agrave; afficher',
  ),
);
