<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': activeer om kolom oplopend te sorteren',
      'sortDescending' => ': activeer om kolom aflopend te sorteren',
    ),
    'emptyTable' => 'Geen resultaten aanwezig in de tabel',
    'info' => '_START_ tot _END_ van _TOTAL_ resultaten',
    'infoEmpty' => 'Geen resultaten om weer te geven',
    'infoFiltered' => '(gefilterd uit _MAX_ resultaten)',
    'infoThousands' => '.',
    'lengthMenu' => '_MENU_ resultaten weergeven',
    'loadingRecords' => 'Een moment geduld aub - bezig met laden...',
    'paginate' => 
    array (
      'first' => 'Eerste',
      'last' => 'Laatste',
      'next' => 'Volgende',
      'previous' => 'Vorige',
    ),
    'processing' => 'Bezig...',
    'search' => 'Zoeken:',
    'zeroRecords' => 'Geen resultaten gevonden',
  ),
);
