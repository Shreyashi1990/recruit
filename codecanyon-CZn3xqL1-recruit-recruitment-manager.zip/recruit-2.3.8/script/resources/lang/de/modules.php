<?php

return array (
  'datatables' => 
  array (
    'emptyTable' => 'Keine Daten in der Tabelle vorhanden',
    'info' => '_START_ bis _END_ von _TOTAL_ Einträgen',
    'infoEmpty' => 'Keine Daten vorhanden',
    'infoFiltered' => '(gefiltert von _MAX_ Einträgen)',
    'infoThousands' => '.',
    'lengthMenu' => '_MENU_ Einträge anzeigen',
    'loadingRecords' => 'Wird geladen ..',
    'paginate' => 
    array (
      'first' => 'Erste',
      'last' => 'Letzte',
      'next' => 'Nächste',
      'previous' => 'Zurück',
    ),
    'processing' => 'Bitte warten ..',
    'search' => 'Suchen',
    'zeroRecords' => 'Keine Einträge vorhanden',
    'aria' => 
    array (
      'sortAscending' => ': aktivieren, um Spalte aufsteigend zu sortieren',
      'sortDescending' => ': aktivieren, um Spalte absteigend zu sortieren',
    ),
  ),
);
