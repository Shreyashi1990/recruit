<?php

return array (
  'title' => 'Instalador de Laravel',
  'next' => 'Siguiente',
  'finish' => 'Instalar',
  'welcome' => 
  array (
    'title' => 'Bienvenido al instalador',
    'message' => 'Bienvenido al asistente de configuración',
  ),
  'requirements' => 
  array (
    'title' => 'Requisitos',
  ),
  'permissions' => 
  array (
    'title' => 'Permisos',
  ),
  'environment' => 
  array (
    'title' => 'Configuraciones del entorno',
    'save' => 'Guardar archivo .env',
    'success' => 'Los cambios en tu archivo .env han sido guardados.',
    'errors' => 'No es posible crear el archivo .env, por favor intentalo manualmente.',
  ),
  'final' => 
  array (
    'title' => 'Finalizado.',
    'finished' => 'La aplicación ha sido instalada con éxito!',
    'exit' => 'Haz click aquí para salir.',
  ),
);
