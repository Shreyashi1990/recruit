<?php

return array (
  'dashboard' => 'salpicadero',
);
