<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': ενεργοποιήστε για αύξουσα ταξινόμηση της στήλης',
      'sortDescending' => ': ενεργοποιήστε για φθίνουσα ταξινόμηση της στήλης',
    ),
    'emptyTable' => 'Δεν υπάρχουν δεδομένα στον πίνακα',
    'info' => 'Εμφανίζονται _START_ έως _END_ από _TOTAL_ εγγραφές',
    'infoEmpty' => 'Εμφανίζονται 0 έως 0 από 0 εγγραφές',
    'infoFiltered' => '(φιλτραρισμένες από _MAX_ συνολικά εγγραφές)',
    'infoThousands' => '.',
    'lengthMenu' => 'Δείξε _MENU_ εγγραφές',
    'loadingRecords' => 'Φόρτωση...',
    'paginate' => 
    array (
      'first' => 'Πρώτη',
      'last' => 'Τελευταία',
      'next' => 'Επόμενη',
      'previous' => 'Προηγούμενη',
    ),
    'processing' => 'Επεξεργασία...',
    'search' => 'Αναζήτηση:',
    'zeroRecords' => 'Δεν βρέθηκαν εγγραφές που να ταιριάζουν',
  ),
);
