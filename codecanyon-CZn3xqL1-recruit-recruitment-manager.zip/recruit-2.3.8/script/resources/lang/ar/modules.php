<?php

return array (
  'datatables' => 
  array (
    'info' => 'إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل',
    'infoEmpty' => 'يعرض 0 إلى 0 من أصل 0 سجل',
    'infoFiltered' => '(منتقاة من مجموع _MAX_ مُدخل)',
    'lengthMenu' => 'أظهر _MENU_ مدخلات',
    'paginate' => 
    array (
      'first' => 'الأول',
      'last' => 'الأخير',
      'next' => 'التالي',
      'previous' => 'السابق',
    ),
    'processing' => 'جارٍ التحميل...',
    'search' => 'ابحث:',
    'zeroRecords' => 'لم يعثر على أية سجلات',
    'emptyTable' => 'لا توجد بيانات متاحة في الجدول',
    'infoThousands' => ',',
    'loadingRecords' => 'جار التحميل...',
    'aria' => 
    array (
      'sortAscending' => ': تفعيل لفرز العمود تصاعدي',
      'sortDescending' => ': تفعيل لفرز العمود تنازلي',
    ),
  ),
);
