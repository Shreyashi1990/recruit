<?php

return array (
  'title' => 'Laravel Installer',
  'next' => 'Sonraki Adım',
  'welcome' => 
  array (
    'title' => 'Installer\'a Hoşgeldiniz',
    'message' => 'Kurulum sihirbazına hoşgeldiniz.',
  ),
  'requirements' => 
  array (
    'title' => 'Gereksinimler',
  ),
  'permissions' => 
  array (
    'title' => 'İzinler',
  ),
  'environment' => 
  array (
    'title' => 'Ortam Ayarları',
    'save' => '.env\'yi Kaydet',
    'success' => '.env dosyanız kaydedildi.',
    'errors' => '.env dosyanız kaydedilemedi, lütfen manuel yaratınız.',
  ),
  'final' => 
  array (
    'title' => 'Tamamlandı',
    'finished' => 'Uygulama başarıyla yüklendi.',
    'exit' => 'Çıkış yapmak için tıklayınız',
  ),
);
