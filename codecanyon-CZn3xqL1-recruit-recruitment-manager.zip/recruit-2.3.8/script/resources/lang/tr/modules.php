<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': artan sütun sıralamasını aktifleştir',
      'sortDescending' => ': azalan sütun sıralamasını aktifleştir',
    ),
    'emptyTable' => 'Tabloda herhangi bir veri mevcut değil',
    'info' => '_TOTAL_ kayıttan _START_ - _END_ arasındaki kayıtlar gösteriliyor',
    'infoEmpty' => 'Kayıt yok',
    'infoFiltered' => '(_MAX_ kayıt içerisinden bulunan)',
    'infoThousands' => '.',
    'lengthMenu' => 'Sayfada _MENU_ kayıt göster',
    'loadingRecords' => 'Yükleniyor...',
    'paginate' => 
    array (
      'first' => 'İlk',
      'last' => 'Son',
      'next' => 'Sonraki',
      'previous' => 'Önceki',
    ),
    'processing' => 'İşleniyor...',
    'search' => 'Ara:',
    'zeroRecords' => 'Eşleşen kayıt bulunamadı',
  ),
);
