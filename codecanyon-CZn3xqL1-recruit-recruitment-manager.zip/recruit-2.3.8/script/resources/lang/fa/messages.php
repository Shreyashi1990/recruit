<?php

return array (
  'title' => 'نصب کننده لاراول',
  'next' => 'قدم بعدی',
  'welcome' => 
  array (
    'title' => 'به نصب کننده خوش آمدید',
    'message' => 'به جادوگر نصب خوش آمدید .',
  ),
  'requirements' => 
  array (
    'title' => 'نیازمندی ها',
  ),
  'permissions' => 
  array (
    'title' => 'مجوز های دسترسی',
  ),
  'environment' => 
  array (
    'title' => 'تنظیمات پیکربندی',
    'save' => 'ذخیره کردن .env',
    'success' => 'فایل .env برای شما ذخیره شد.',
    'errors' => 'ذخیره کردن فایل .env امکان پذیر نیست، لطفا آن را به صورت دستی ایجاد کنید.',
  ),
  'final' => 
  array (
    'title' => 'تمام شد',
    'finished' => 'اپلیکیشن با موفقیت نصب شد.',
    'exit' => 'برای خروج اینجا را کلیک کنید',
  ),
);
