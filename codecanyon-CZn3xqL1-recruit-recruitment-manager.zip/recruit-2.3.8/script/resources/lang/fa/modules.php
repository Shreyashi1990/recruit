<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': فعال سازی نمایش به صورت صعودی',
      'sortDescending' => ': فعال سازی نمایش به صورت نزولی',
    ),
    'emptyTable' => 'هیچ داده ای در جدول وجود ندارد',
    'info' => 'نمایش _START_ تا _END_ از _TOTAL_ رکورد',
    'infoEmpty' => 'نمایش 0 تا 0 از 0 رکورد',
    'infoFiltered' => '(فیلتر شده از _MAX_ رکورد)',
    'infoThousands' => ',',
    'lengthMenu' => 'نمایش _MENU_ رکورد',
    'loadingRecords' => 'در حال بارگزاری...',
    'paginate' => 
    array (
      'first' => 'ابتدا',
      'last' => 'انتها',
      'next' => 'بعدی',
      'previous' => 'قبلی',
    ),
    'processing' => 'در حال پردازش...',
    'search' => 'جستجو:',
    'zeroRecords' => 'رکوردی با این مشخصات پیدا نشد',
  ),
);
