<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': Ordenar colunas de forma ascendente',
      'sortDescending' => ': Ordenar colunas de forma descendente',
    ),
    'emptyTable' => 'Nenhum registro encontrado',
    'info' => 'Mostrando de _START_ até _END_ de _TOTAL_ registos',
    'infoEmpty' => 'Mostrando de 0 até 0 de 0 registos',
    'infoFiltered' => '(Filtrados de _MAX_ registros)',
    'infoThousands' => ',',
    'lengthMenu' => '_MENU_ resultados por página',
    'loadingRecords' => 'Carregando...',
    'paginate' => 
    array (
      'first' => 'Primeiro',
      'last' => 'Último',
      'next' => 'Próximo',
      'previous' => 'Anterior',
    ),
    'processing' => 'Processando...',
    'search' => 'Pesquisar',
    'zeroRecords' => 'Nenhum registro encontrado',
  ),
);
