<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': attiva per ordinare la colonna in ordine crescente',
      'sortDescending' => ': attiva per ordinare la colonna in ordine decrescente',
    ),
    'emptyTable' => 'Nessun dato presente nella tabella',
    'info' => 'Vista da _START_ a _END_ di _TOTAL_ elementi',
    'infoEmpty' => 'Vista da 0 a 0 di 0 elementi',
    'infoFiltered' => '(filtrati da _MAX_ elementi totali)',
    'infoThousands' => '.',
    'lengthMenu' => 'Visualizza _MENU_ elementi',
    'loadingRecords' => 'Caricamento...',
    'paginate' => 
    array (
      'first' => 'Inizio',
      'last' => 'Fine',
      'next' => 'Successivo',
      'previous' => 'Precedente',
    ),
    'processing' => 'Elaborazione...',
    'search' => 'Cerca:',
    'zeroRecords' => 'La ricerca non ha portato alcun risultato.',
  ),
);
