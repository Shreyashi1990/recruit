<?php

return array (
  'datatables' => 
  array (
    'aria' => 
    array (
      'sortAscending' => ': activați pentru a sorta coloana ascendentă',
      'sortDescending' => ': activați pentru a sorta coloana descrescătoare',
    ),
    'emptyTable' => 'Nu există date disponibile în tabel',
    'info' => 'Afișate de la _START_ la _END_ din _TOTAL_ înregistrări',
    'infoEmpty' => 'Afișate de la 0 la 0 din 0 înregistrări',
    'infoFiltered' => '(filtrate dintr-un total de _MAX_ înregistrări)',
    'infoThousands' => ',',
    'lengthMenu' => 'Afișează _MENU_ înregistrări pe pagină',
    'loadingRecords' => 'Se încarcă...',
    'paginate' => 
    array (
      'first' => 'Prima',
      'last' => 'Ultima',
      'next' => 'Următoarea',
      'previous' => 'Precedenta',
    ),
    'processing' => 'Procesează...',
    'search' => 'Caută:',
    'zeroRecords' => 'Nu am găsit nimic - ne pare rău',
  ),
);
